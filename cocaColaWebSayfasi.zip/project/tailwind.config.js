/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'coca-cola': {
          red: '#F40009',
          white: '#FFFFFF',
          gray: '#2B2B2B',
        },
      },
      fontFamily: {
        'coca-cola': ['Helvetica', 'Arial', 'sans-serif'],
      },
    },
  },
  plugins: [],
};