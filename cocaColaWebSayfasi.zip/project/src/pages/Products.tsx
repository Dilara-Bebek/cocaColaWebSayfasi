import React, { useState } from 'react';
import { Search, Star } from 'lucide-react';

const products = [
  {
    id: 1,
    name: "Coca-Cola Orijinal",
    brand: "coca-cola",
    category: "gazlı-içecek",
    image: "https://i.pinimg.com/236x/93/8a/a8/938aa8cfd84e7bf63df7b711e449369b.jpg",
    description: "Klasik Coca-Cola lezzeti",
    variants: ["200ml Cam Şişe", "330ml Kutu", "1L Pet Şişe", "2.5L Pet Şişe"],
    rating: 4.9
  },
  {
    id: 2,
    name: "Coca-Cola Zero Sugar",
    brand: "coca-cola",
    category: "gazlı-içecek",
    image: "https://st2.depositphotos.com/1029150/8188/i/450/depositphotos_81882536-stock-photo-coca-cola-cans.jpg",
    description: "Coca-Cola Zero lezzeti, Gerçek sıfır şeker!",
    variants: ["330ml Kutu", "1L Pet Şişe", "2.5L Pet Şişe"],
    rating: 4.8
  },
  {
    id: 3,
    name: "Fanta Portakal Zero Sugar",
    brand: "fanta",
    category: "gazlı-içecek",
    image: "https://i1.sndcdn.com/artworks-000526386432-i03mpu-t1080x1080.jpg",
    description: "Portakal aromalı Şekersiz gazlı içecek",
    variants: ["330ml Kutu", "1L Pet Şişe", "2.5L Pet Şişe"],
    rating: 4.7
  },
  {
    id: 4,
    name: "Sprite",
    brand: "sprite",
    category: "gazlı-içecek",
    image: "https://s.alicdn.com/@sc04/kf/Ab7623daeca0c4bbfb8e828b031d0aedfa.jpg",
    description: "Limon aromalı ferahlatıcı içecek",
    variants: ["330ml Kutu", "1L Pet Şişe", "2.5L Pet Şişe"],
    rating: 4.8
  },
  {
    id: 5,
    name: "Schweppes Tonik Suyu",
    brand: "schweppes",
    category: "mixer",
    image: "https://www.coca-cola.com/content/dam/onexp/tr/tr/brands/schweppes/Hero-Schweppes.jpeg",
    description: "Premium tonik su",
    variants: ["200ml Cam Şişe", "1L Pet Şişe"],
    rating: 4.6
  },
  {
    id: 6,
    name: "Cappy Karışık Meyve Suyu",
    brand: "cappy",
    category: "meyve-suyu",
    image: "https://www.coca-cola.com/content/dam/onexp/tr/tr/brands/cappy/cappy-desktop.jpg",
    description: "Taze sıkılmış meyve lezzeti",
    variants: ["330ml Cam Şişe", "1L Pet Şişe"],
    rating: 4.5
  },
  {
    id: 7,
    name: "Damla Su",
    brand: "damla",
    category: "su",
    image: "https://images.unsplash.com/photo-1548839140-29a749e1cf4d?auto=format&fit=crop&w=800",
    description: "Doğal kaynak suyu",
    variants: ["0.5L Pet Şişe", "1.5L Pet Şişe", "5L Pet Şişe", "19L Damacana"],
    rating: 4.7
  },
  {
    id: 8,
    name: "Fusea Tea",
    brand: "fuseatea",
    category: "Fusea Tea",
    image: "https://images.ofix.com/product-image/q115514-buyuk.jpg?output=webp&w=500",
    description: "Yoğun aromalı soğuk çay lezzeti",
    variants: ["0.5L Pet Şişe", "1.5L Pet Şişe"],
    rating: 4.6
  },
  {
    id: 9,
    name: "Coca-Cola Lime",
    brand: "coca-cola",
    category: "Coca-Cola",
    image: "https://m.media-amazon.com/images/I/81ADQld1XAL._AC_UF894,1000_QL80_.jpg",
    description: "Limon aromalı Coca-Cola lezzeti",
    variants: ["0.5L Pet Şişe", "1.5L Pet Şişe"],
    rating: 4.6
  },
  {
    id: 10,
    name: "Fanta Portakal",
    brand: "fanta",
    category: "Fanta",
    image: "https://static.ticimax.cloud/56595/uploads/urunresimleri/buyuk/fanta-portakal-aromali-gazoz-2d2720.jpg",
    description: "Klasik Fanta lezzeti",
    variants: ["0.5L Pet Şişe", "1.5L Pet Şişe"],
    rating: 4.6
  },
  {
    id: 11,
    name: "Şekersiz Sprite",
    brand: "sprite",
    category: "Sprite",
    image: "https://cdn.shopify.com/s/files/1/1958/6183/files/Sprite-Zero-Sugar-Soft-Drink-Multipack-Bottles_-12-x-1.25L--Sprite-Hello-Drinks-1684189739.jpg?v=1684189740",
    variants: ["0.5L Pet Şişe", "1.5L Pet Şişe"],
    rating: 4.6
  },
  {
    id: 12,
    name: "Powerade Karışık Meyve Lezzetli Spor İçeceği ",
    brand: "powerade",
    category: "Powerade",
    image: "https://www.coca-cola.com/content/dam/onexp/tr/tr/brands/powerade/tr_powerade_prod_powerade-iceblast_750x750.jpg/width1960.jpg",
    variants: ["0.5L Pet Şişe", "1.5L Pet Şişe"],
    rating: 4.6
  }
  
];

function Products() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [activeBrand, setActiveBrand] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = products.filter(product => {
    const matchesFilter = activeFilter === 'all' || product.category === activeFilter;
    const matchesBrand = activeBrand === 'all' || product.brand === activeBrand;
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesBrand && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Hero Section */}
      <div className="bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-8">Ürünlerimiz</h1>
            
            {/* Search Bar */}
            <div className="max-w-2xl mx-auto mb-12">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Ürün ara..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-3 pl-12 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-coca-cola-red focus:border-transparent"
                />
                <Search className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" />
              </div>
            </div>

            {/* Brand Filters */}
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              {['Tümü', 'coca-cola', 'fanta', 'sprite', 'schweppes', 'cappy', 'damla', 'Fusea Tea','PowerAde'].map((brand) => (
                <button
                  key={brand}
                  onClick={() => setActiveBrand(brand)}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                    activeBrand === brand
                      ? 'bg-coca-cola-red text-white'
                      : 'bg-white text-gray-600 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  {brand === 'Tümü' ? 'Tüm Markalar' : brand.charAt(0).toUpperCase() + brand.slice(1)}
                </button>
              ))}
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              {['Tümü', 'gazlı-içecek', 'meyve-suyu', 'mixer', 'su'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                    activeFilter === filter
                      ? 'bg-gray-900 text-white'
                      : 'bg-white text-gray-600 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  {filter === 'Tümü' ? 'Tüm Kategoriler' : filter.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Products Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredProducts.map((product) => (
            <div key={product.id} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300 transform hover:-translate-y-2">
              <div className="relative aspect-w-4 aspect-h-3">
                <img
                  src={product.image}
                  alt={product.name}
                  className="w-full h-64 object-contain p-4"
                />
                <div className="absolute top-4 right-4 px-3 py-1 rounded-full text-sm bg-white shadow-md">
                  <div className="flex items-center">
                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                    <span className="font-medium">{product.rating}</span>
                  </div>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">{product.name}</h3>
                <p className="text-gray-600 mb-4">{product.description}</p>
                <div className="mb-4">
                  <h4 className="text-sm font-semibold text-gray-900 mb-2">Mevcut Seçenekler:</h4>
                  <div className="flex flex-wrap gap-2">
                    {product.variants.map((variant, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 text-sm bg-gray-100 rounded-full text-gray-700"
                      >
                        {variant}
                      </span>
                    ))}
                  </div>
                </div>
                <button className="w-full py-2 rounded-lg bg-coca-cola-red text-white hover:bg-red-700 transition-colors">
                  Detayları Gör
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default Products;