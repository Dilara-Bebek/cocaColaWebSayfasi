import React, { useState } from 'react';
import { ArrowRight, Play, Pause } from 'lucide-react';
import { Link } from 'react-router-dom';

function Home() {
  const [isPlaying, setIsPlaying] = useState(true);

  const toggleVideo = () => {
    const video = document.getElementById('hero-video') as HTMLVideoElement;
    if (video) {
      if (isPlaying) {
        video.pause();
      } else {
        video.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <div className="relative h-screen">
        {/* Background Video */}
        <div className="absolute inset-0">
          <video
            id="hero-video"
            autoPlay
            loop
            muted
            playsInline
            className="w-full h-full object-cover"
          >
            <source
              src="https://assets.mixkit.co/videos/5081/5081-720.mp4"
              type="video/mp4"
            />
          </video>
          <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/30 to-black/60"></div>
        </div>
        
        {/* Video Controls */}
        <button
          onClick={toggleVideo}
          className="absolute bottom-8 right-8 z-10 p-3 bg-white/10 backdrop-blur-sm rounded-full hover:bg-white/20 transition-all duration-300 group"
          aria-label={isPlaying ? 'Pause video' : 'Play video'}
        >
          {isPlaying ? (
            <Pause className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />
          ) : (
            <Play className="w-6 h-6 text-white group-hover:scale-110 transition-transform" />
          )}
        </button>
        
        {/* Hero Content */}
        <div className="relative h-full flex items-center justify-center text-center">
          <div className="max-w-4xl px-4">
            <h1 className="text-6xl md:text-7xl font-bold text-white mb-6 animate-fade-in">
              Mutluluğun Tadı
            </h1>
            <p className="text-xl md:text-2xl text-white mb-12 animate-fade-in-delay">
              Coca-Cola ile hayatın her anını özel kıl!
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
              <Link
                to="/daha-daha"
                className="group inline-flex items-center px-8 py-4 bg-coca-cola-red text-white rounded-full text-lg font-semibold hover:bg-red-700 transition-all transform hover:scale-105"
              >
                Fırsatları Keşfet
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
              <Link
                to="/products"
                className="group inline-flex items-center px-8 py-4 bg-white text-coca-cola-red rounded-full text-lg font-semibold hover:bg-gray-100 transition-all transform hover:scale-105"
              >
                Ürünlerimiz
                <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-8 h-12 border-2 border-white rounded-full flex items-start justify-center p-2">
            <div className="w-1 h-3 bg-white rounded-full animate-scroll"></div>
          </div>
        </div>
      </div>

      {/* Featured Section */}
      <div className="bg-white py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-4">Coca-Cola Dünyasına Hoş Geldiniz</h2>
            <p className="text-xl text-gray-600">Ferahlığın ve mutluluğun buluşma noktası</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="group relative overflow-hidden rounded-2xl transform hover:-translate-y-2 transition-all duration-300">
              <img
                src="https://www.coca-cola.com/content/dam/onexp/ie/en/offerings-2024/coke-summer/h287492_d183951_tccc_2024_cc_summer-umbrella-promo_one-xp-landing-page_nl_1440x810.png/width1960.png"
                alt="Coca-Cola"
                className="w-full h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-75"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="text-2xl font-bold mb-2">Yeni Kampanyalar</h3>
                <p className="mb-4">Her gün yeni fırsatlarla karşınızdayız!</p>
                <Link
                  to="/daha-daha"
                  className="inline-flex items-center text-sm font-semibold hover:text-coca-cola-red transition-colors"
                >
                  Detayları Gör
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </div>
            <div className="group relative overflow-hidden rounded-2xl transform hover:-translate-y-2 transition-all duration-300">
              <img
                src="https://blog.ofix.com/wp-content/uploads/2018/04/coca_cola_ofix_blog.jpg"
                alt="Products"
                className="w-full h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-75"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="text-2xl font-bold mb-2">Ürün Yelpazesi</h3>
                <p className="mb-4">Tüm markalarımızı keşfedin</p>
                <Link
                  to="/products"
                  className="inline-flex items-center text-sm font-semibold hover:text-coca-cola-red transition-colors"
                >
                  Ürünleri İncele
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </div>
            <div className="group relative overflow-hidden rounded-2xl transform hover:-translate-y-2 transition-all duration-300">
              <img
                src="https://mir-s3-cdn-cf.behance.net/project_modules/max_1200/36f72041710471.57b1972607ebc.jpg"
                alt="Events"
                className="w-full h-64 object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-75"></div>
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="text-2xl font-bold mb-2">Özel Etkinlikler</h3>
                <p className="mb-4">Unutulmaz deneyimler için takipte kalın</p>
                <Link
                  to="/daha-daha"
                  className="inline-flex items-center text-sm font-semibold hover:text-coca-cola-red transition-colors"
                >
                  Etkinlikleri Gör
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Home;