import React, { useState } from 'react';
import { Search, Star, Calendar } from 'lucide-react';

function DahaDaha() {
  const [activeFilter, setActiveFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const campaigns = [
    {
      id: 1,
      title: "250.000 TL Değerinde ParamKart",
      category: "ParamKart",
      image: "https://prod-extrazone-document-bucket.s3.eu-west-1.amazonaws.com/promotiondetailitems/tr/93bae06d-9028-44c9-8a97-677fb4360045/tr/desktop/cc239562-89ac-4363-9603-3af9cb3c12bc.png",
      description: "Üzerinde 'BOŞ YOK' ibaresi bulunan kapaklar kazandırıyor. Her bir kapak koduyla 250,000 TL ParamKart kazanma şansını yakala!",
      endDate: "31 Ağustos 2025",
      status: "active",
      brand: "Coca-Cola",
      points: 100
    },
    {
      id: 2,
      title: "Dijital Bakiye",
      category: "Dijital Bakiye",
      image: "https://prod-extrazone-document-bucket.s3.eu-west-1.amazonaws.com/promotiondetailitems/tr/abce1f94-2e46-4bda-9e34-90a9a018b44b/tr/desktop/51f1657e-0c2b-4a59-81b5-6fa5e9d8dce2.jpeg",
      description: "Yıldızlı boş yok kapaklarının altındaki kodu Daha Daha'ya gir,350TL değerine varan Money, Nays veya Param hediyelerinden birini kazan!",
      endDate: "30 Mayıs 2025",
      status: "active",
      brand: "Coca-Cola",
      points: 150
    },
    {
      id: 3,
      title: "Bedava İnternet",
      category: "İnternet",
      image: "https://prod-extrazone-document-bucket.s3.eu-west-1.amazonaws.com/promotiondetailitems/tr/0a41a028-86d2-4036-876b-70932d8a22c9/tr/desktop/b03af116-3ae3-46a4-874b-a291cadedead.jpeg",
      description: "Yıldızlı boş yok kapaklarının altındaki kodu Daha Daha'ya gir,100MB - 250MB - 1GB - 2GB internet kazanma şansını yakala",
      endDate: "31 Ağustos 2025",
      status: "active",
      brand: "Coca-Cola",
      points: 200
    },
    {
      id: 4,
      title: "Fusetea Kapakları ile 500 Pegasus BolPuan Kazan!",
      category: "Ulaşım",
      image: "https://prod-extrazone-document-bucket.s3.eu-west-1.amazonaws.com/promotiongallery/tr/24e881fb-f9f6-4777-9ce5-87dc65c97dbc/tr/desktop/5adefb36-65a5-4d7c-a825-48cf2749cde4.webp",
      description: "Migros'ta Gümüş renkli Fusetea 1L kapakları 500 Pegasus BolPuan kazandırıyor! Üstelik 15.000 BolPuan'a kadar biriktirebilirsin! ",
      endDate: "31 Aralık 2025",
      status: "active",
      brand: "Coca-Cola",
      points: 75
    },
    {
      id: 5,
      title: "Petrol Ofisinden Burger Yiyelim Menü Hediye!",
      category: "yemek",
      image: "https://prod-extrazone-document-bucket.s3.eu-west-1.amazonaws.com/promotiongallery/tr/934e8ff7-a327-49ec-bc2c-936dff2eaf4d/tr/desktop/e0ad0918-40d5-4753-8d67-9c433e287b78.webp",
      description: "Burger Yiyelim'de hediye Cheeseburger Menü kazanma şansı seni bekliyor. Petrol Ofisinden alacağın kod ile hediye menünü kaçırma!",
      endDate: "30 Eylül 2025",
      status: "active",
      brand: "Coca-Cola",
      points: 125
    },
    {
      id: 6,
      title: "Coca-Cola Daha Daha Kodu ile FUPS Diye 100 TL Kazan!",
      category: "alışveriş",
      image: "https://fups.com/static/img/pages/campaign/campaign-detail/coca-cola/dahadaha-web.png",
      description: "Coca-Cola orijinal, Zero Sugar ve Sprite yıldızlı kapakları ile Daha Daha uygulaması veya web sitesinden aldığın FUPS indirim kodunu al,her ay tüm alışverişlerinde kullanabileceğin 100 TL kazan.",
      endDate: "31 Temmuz 2025",
      status: "active",
      brand: "Coca-Cola",
      points: 90
    },
    {
      id: 7,
      title: "Yemeğinin tadını çıkar diye 1 menü alana 1 menü hediye!",
      category: "Yemek",
      image: "https://cdnuploads.aa.com.tr/uploads/sirkethaberleri/Contents/2021/01/18/thumbs_b_c_20c4a93c302111105e4c92c7907414b3.jpg",
      description: "Hemen yıldızlı Coca-Cola Zero Sugar kapaklarındaki kodlan gir, Popeyes'dan Popchicken Menü alışverişinde 1 alana 1 menü hediye kampanyasından yararlan! 🍔",
      endDate: "31 Temmuz 2025",
      status: "active",
      brand: "Coca-Cola",
      points: 90
    },
    {
      id: 8,
      title: "Kütahya Porselen ' de geçerli 1500 TL indirim kodu 300 TL",
      category: "Alışveriş",
      image: "https://cdn.r10.net/editor/169771/3529203810.png",
      description: " 1500 TL'ye kadar biriktirilebilir Kütahya Porselen indirim kodunun seni bekliyor!",
      endDate: "31 Temmuz 2025",
      status: "active",
      brand: "Coca-Cola",
      points: 90
    },
    {
      id: 9,
      title: "BMW İX Çekilişi",
      category: "Alışveriş",
      image: "https://www.kimkazandi.com/userfiles/resimler/Schweppes_BMW_Cekilisi_23L.jpg",
      description: "Şimdi Schweppes Tadını Çıkar, BMW iX Kazanma Şansı Yakala! 🚗🥤Schweppes al, çekilişe katıl, hayalini kurduğun BMW iX’e bir adım daha yaklaş! Keşke demektense sen de kazan!",
      endDate: "31 Temmuz 2025",
      status: "coming",
      brand: "Coca-Cola",
      points: 90
    }
    
  ];

  const filteredCampaigns = campaigns.filter(campaign => {
    const matchesFilter = activeFilter === 'all' || campaign.category === activeFilter;
    const matchesSearch = campaign.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         campaign.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      {/* Hero Section */}
      <div className="bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-8">Daha Fazla Coca-Cola, Daha Fazla Fırsat!</h1>
            
            {/* Search Bar */}
            <div className="max-w-2xl mx-auto mb-12">
              <div className="relative">
                <input
                  type="text"
                  placeholder="Kampanya ara..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full px-4 py-3 pl-12 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-coca-cola-red focus:border-transparent"
                />
                <Search className="absolute left-4 top-3.5 h-5 w-5 text-gray-400" />
              </div>
            </div>

            {/* Category Filters */}
            <div className="flex flex-wrap justify-center gap-4 mb-12">
              {['Tümü', 'çekiliş', 'spor', 'eğlence', 'yemek', 'alışveriş','ParamKart','Dijital Bakiye','İnternet','Ulaşım'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setActiveFilter(filter)}
                  className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
                    activeFilter === filter
                      ? 'bg-coca-cola-red text-white'
                      : 'bg-white text-gray-600 border border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  {filter.charAt(0).toUpperCase() + filter.slice(1)}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Campaigns Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCampaigns.map((campaign) => (
            <div key={campaign.id} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="relative">
                <img
                  src={campaign.image}
                  alt={campaign.title}
                  className="w-full h-85 object-cover"
                />
                <div className={`absolute top-4 right-4 px-3 py-1 rounded-full text-sm ${
                  campaign.status === 'active'
                    ? 'bg-coca-cola-red text-white'
                    : 'bg-gray-200 text-gray-600'
                }`}>
                  {campaign.status === 'active' ? 'Aktif' : 'Yakında'}
                </div>
              </div>
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-xl font-bold">{campaign.title}</h3>
                  <div className="flex items-center">
                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                    <span className="text-sm font-medium">{campaign.points} Puan</span>
                  </div>
                </div>
                <p className="text-gray-600 mb-4">{campaign.description}</p>
                <div className="flex items-center text-sm text-gray-500 mb-4">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>Son Tarih: {campaign.endDate}</span>
                </div>
                <button className={`w-full py-2 rounded-lg transition-colors ${
                  campaign.status === 'active'
                    ? 'bg-coca-cola-red text-white hover:bg-red-700'
                    : 'bg-gray-200 text-gray-600 cursor-not-allowed'
                }`}>
                  {campaign.status === 'active' ? 'Hemen Katıl' : 'Yakında'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default DahaDaha;