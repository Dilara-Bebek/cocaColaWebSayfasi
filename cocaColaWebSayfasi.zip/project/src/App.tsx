import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import Home from './pages/Home';
import DahaDaha from './pages/DahaDaha';
import Products from './pages/Products';

function App() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <Router>
      <div className="font-coca-cola">
        {/* Navigation */}
        <nav className={`fixed w-full z-50 transition-all duration-300 ${
          isScrolled ? 'bg-white shadow-lg' : 'bg-transparent'
        }`}>
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center h-20">
              {/* Logo - Left aligned */}
              <div className="flex-shrink-0">
                <Link to="/" className="flex items-center">
                  <img 
                    src="https://www.coca-cola.com/content/dam/onexp/tr/tr/logo-color/updated/Cocacola-Turkiye-logo-124x20-80.svg"
                    alt="Coca-Cola Türkiye"
                    className="h-12"
                  />
                </Link>
              </div>
              
              {/* Navigation Links - Right aligned */}
              <div className="hidden md:flex flex-1 justify-end">
                <div className="flex items-center space-x-12">
                  <Link to="/" className={`transition-colors text-lg font-bold ${
                    window.location.pathname === '/' 
                      ? 'text-coca-cola-red' 
                      : 'text-gray-900 hover:text-coca-cola-red'
                  }`}>
                    Anasayfa
                  </Link>
                  <Link to="/products" className={`transition-colors text-lg font-bold ${
                    window.location.pathname === '/products'
                      ? 'text-coca-cola-red'
                      : 'text-gray-900 hover:text-coca-cola-red'
                  }`}>
                    Ürünler
                  </Link>
                  <Link to="/daha-daha" className={`transition-colors text-lg font-bold ${
                    window.location.pathname === '/daha-daha'
                      ? 'text-coca-cola-red'
                      : 'text-gray-900 hover:text-coca-cola-red'
                  }`}>
                    Daha Daha
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </nav>

        {/* Routes */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/products" element={<Products />} />
          <Route path="/daha-daha" element={<DahaDaha />} />
        </Routes>

        {/* Footer */}
        <footer className="bg-coca-cola-gray text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              <div>
                <h4 className="text-lg font-bold mb-4">Hakkımızda</h4>
                <ul className="space-y-2">
                  <li><a href="#" className="hover:text-coca-cola-red">Şirketimiz</a></li>
                  <li><a href="#" className="hover:text-coca-cola-red">Kariyer</a></li>
                  <li><a href="#" className="hover:text-coca-cola-red">Haberler</a></li>
                </ul>
              </div>
              <div>
                <h4 className="text-lg font-bold mb-4">Ürünler</h4>
                <ul className="space-y-2">
                  <li><a href="#" className="hover:text-coca-cola-red">Markalar</a></li>
                  <li><a href="#" className="hover:text-coca-cola-red">Ürünler</a></li>
                  <li><a href="#" className="hover:text-coca-cola-red">Tarifler</a></li>
                </ul>
              </div>
              <div>
                <h4 className="text-lg font-bold mb-4">Daha Daha</h4>
                <ul className="space-y-2">
                  <li><a href="#" className="hover:text-coca-cola-red">Aktif Kampanyalar</a></li>
                  <li><a href="#" className="hover:text-coca-cola-red">Yaklaşan Kampanyalar</a></li>
                  <li><a href="#" className="hover:text-coca-cola-red">Puan Kataloğu</a></li>
                </ul>
              </div>
              <div>
                <h4 className="text-lg font-bold mb-4">İletişim</h4>
                <ul className="space-y-2">
                  <li><a href="#" className="hover:text-coca-cola-red">Destek</a></li>
                  <li><a href="#" className="hover:text-coca-cola-red">SSS</a></li>
                  <li><a href="#" className="hover:text-coca-cola-red">Bize Ulaşın</a></li>
                </ul>
              </div>
            </div>
            <div className="mt-12 pt-8 border-t border-gray-700 text-center">
              <p>© {new Date().getFullYear()} The Coca-Cola Company. Tüm hakları saklıdır.</p>
            </div>
          </div>
        </footer>
      </div>
    </Router>
  );
}

export default App;